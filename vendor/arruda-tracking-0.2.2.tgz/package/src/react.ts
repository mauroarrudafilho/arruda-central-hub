// =============================================================================
// @arruda/tracking/react — hooks React opcionais
// =============================================================================
// Importar com:  import { useTrackPageView } from '@arruda/tracking/react'

import { useEffect, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import { trackPageView } from './index'
import { tracker } from './tracker'

/**
 * Dispara track de page_view automaticamente sempre que a rota muda.
 * `duration_ms` = tempo na página anterior, gravado no page_view dela ao sair
 * (sem segundo evento — substitui o buffer da página anterior se ainda não flushou,
 * senão envia um page_view com duration da página que está fechando).
 *
 * Uso típico: colocar uma vez no layout raiz da aplicação.
 */
export function useTrackPageView(): void {
  const location = useLocation()
  const enteredAtRef = useRef<number>(Date.now())
  const prevPathRef = useRef<string | null>(null)
  const prevTitleRef = useRef<string | undefined>(undefined)

  useEffect(() => {
    const now = Date.now()
    const title =
      typeof document !== 'undefined' ? document.title : undefined

    if (prevPathRef.current) {
      // Permanência da página que está saindo (alimenta Tempo médio no RBAC).
      tracker.track({
        type: 'page_view',
        pagePath: prevPathRef.current,
        pageTitle: prevTitleRef.current,
        durationMs: Math.max(0, now - enteredAtRef.current),
      })
    }

    // View da página atual — sem duration (preenchida ao sair).
    trackPageView(location.pathname, title)

    prevPathRef.current = location.pathname
    prevTitleRef.current = title
    enteredAtRef.current = now
  }, [location.pathname])
}
