// =============================================================================
// Tracker — singleton responsável por bufferizar eventos, gerenciar sessão e
// enviar batches para a edge function rbac-analytics-ingest.
// =============================================================================

import type { TrackingConfig, TrackingEvent, IngestBatch, EventType } from './types'
import { LIB_VERSION } from './types'
import { detectBrowser, detectDevice, detectOs, isDoNotTrack } from './device'
import { normalizePagePath } from './normalizePath'

function genEventId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `evt-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
}

class Tracker {
  private config: Required<Omit<TrackingConfig, 'moduleName'>> & { moduleName?: string }
  private buffer: TrackingEvent[] = []
  private sessionId: string | null = null
  private sessionStartedAt: number = 0
  private lastActivityAt: number = 0
  private flushTimer: ReturnType<typeof setInterval> | null = null
  private authWarmTimer: ReturnType<typeof setInterval> | null = null
  private jwtRetryTimer: ReturnType<typeof setTimeout> | null = null
  private initialized = false
  private enabled = true
  private pendingSessionInit = false
  private flushing = false
  /** Último JWT válido — necessário para flush no unload (getAuthToken pode ser async). */
  private lastAuthToken: string | null = null

  constructor() {
    // defaults temporários; substituídos em init()
    this.config = {
      projectSlug: '',
      supabaseUrl: '',
      getAuthToken: () => null,
      ingestEndpoint: '',
      flushIntervalMs: 10_000,
      flushThreshold: 20,
      maxBufferSize: 500,
      sessionIdleTimeoutMs: 30 * 60 * 1000,
      respectDoNotTrack: true,
      mode: 'frequency',
      debug: false,
    }
  }

  init(config: TrackingConfig) {
    if (this.initialized) {
      this.log('warn', '@arruda/tracking: init() chamado mais de uma vez — ignorando')
      return
    }

    this.config = {
      projectSlug: config.projectSlug,
      supabaseUrl: config.supabaseUrl,
      getAuthToken: config.getAuthToken,
      ingestEndpoint: config.ingestEndpoint ?? `${config.supabaseUrl}/functions/v1/rbac-analytics-ingest`,
      // Intervalo curto: apps com pouco tráfego não devem depender só do unload.
      flushIntervalMs: config.flushIntervalMs ?? 5_000,
      flushThreshold: config.flushThreshold ?? 5,
      maxBufferSize: config.maxBufferSize ?? 500,
      sessionIdleTimeoutMs: config.sessionIdleTimeoutMs ?? 30 * 60 * 1000,
      respectDoNotTrack: config.respectDoNotTrack ?? true,
      /** Default frequency: só page_view alimenta o RBAC; clicks/forms vão pro PostHog. */
      mode: config.mode ?? 'frequency',
      moduleName: config.moduleName,
      debug: config.debug ?? false,
    }

    if (this.config.respectDoNotTrack && isDoNotTrack()) {
      this.enabled = false
      this.log('info', '@arruda/tracking: DNT ativo — tracking desabilitado')
      return
    }

    this.pendingSessionInit = true
    this.flushTimer = setInterval(() => this.flush(), this.config.flushIntervalMs)
    // Cacheia JWT cedo: sessão Supabase costuma hidratar depois do initTracking no main.tsx.
    this.authWarmTimer = setInterval(() => void this.warmAuthToken(), 2_000)
    void this.warmAuthToken()

    if (typeof window !== 'undefined') {
      window.addEventListener('beforeunload', () => this.flushBeacon())
      window.addEventListener('pagehide', () => this.flushBeacon())
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') this.flushBeacon()
      })
    }

    this.initialized = true
    this.log('info', '@arruda/tracking: inicializado para', this.config.projectSlug)
  }

  private async warmAuthToken() {
    if (!this.enabled) return
    try {
      const token = await Promise.resolve(this.config.getAuthToken())
      if (token) {
        const hadToken = !!this.lastAuthToken
        this.lastAuthToken = token
        // Sessão acabou de aparecer e há eventos pendentes → envia já.
        if (!hadToken && this.buffer.length > 0) void this.flush()
      }
    } catch {
      // ignore
    }
  }

  private scheduleJwtRetry() {
    if (this.jwtRetryTimer) return
    this.jwtRetryTimer = setTimeout(() => {
      this.jwtRetryTimer = null
      void this.flush()
    }, 1_500)
  }

  private checkSessionIdle() {
    if (!this.sessionId) return
    if (Date.now() - this.lastActivityAt > this.config.sessionIdleTimeoutMs) {
      this.sessionId = null
      this.pendingSessionInit = true
      this.log('info', 'session idle — nova sessão será criada no próximo flush')
    }
  }

  track(event: {
    type: EventType
    name?: string
    pagePath?: string
    pageTitle?: string
    durationMs?: number
    properties?: Record<string, unknown>
  }) {
    if (!this.initialized || !this.enabled) return

    // Modo frequência: RBAC só precisa de page_view. Clicks/forms/custom → PostHog.
    if (
      this.config.mode === 'frequency' &&
      event.type !== 'page_view'
    ) {
      this.log('info', 'evento ignorado (mode=frequency):', event.type, event.name)
      return
    }

    this.checkSessionIdle()

    const now = Date.now()
    this.lastActivityAt = now

    if (this.buffer.length >= this.config.maxBufferSize) {
      this.buffer.shift()  // descarta o mais antigo
      this.log('warn', 'buffer overflow — evento mais antigo descartado')
    }

    const rawPath =
      event.pagePath ?? (typeof location !== 'undefined' ? location.pathname : undefined)

    this.buffer.push({
      event_id: genEventId(),
      event_type: event.type,
      event_name: event.name,
      page_path: normalizePagePath(rawPath),
      page_title: event.pageTitle ?? (typeof document !== 'undefined' ? document.title : undefined),
      duration_ms: event.durationMs,
      properties: event.properties,
      occurred_at: new Date(now).toISOString(),
      module_name: this.config.moduleName,
    })

    if (this.buffer.length >= this.config.flushThreshold) {
      void this.flush()
    } else if (this.lastAuthToken) {
      // Com JWT já cacheado, não espera o intervalo completo (visitas curtas).
      this.scheduleJwtRetry()
    } else {
      // Sem JWT ainda (sessão hidratando) — tenta de novo em breve.
      this.scheduleJwtRetry()
    }
  }

  trackPageView(pagePath?: string, pageTitle?: string, durationMs?: number) {
    this.track({ type: 'page_view', pagePath, pageTitle, durationMs })
  }

  trackEvent(name: string, properties?: Record<string, unknown>) {
    this.track({ type: 'custom', name, properties })
  }

  trackClick(name: string, properties?: Record<string, unknown>) {
    this.track({ type: 'click', name, properties })
  }

  trackFormSubmit(name: string, properties?: Record<string, unknown>) {
    this.track({ type: 'form_submit', name, properties })
  }

  private buildBatch(events: TrackingEvent[]): IngestBatch {
    const batch: IngestBatch = {
      project_slug: this.config.projectSlug,
      session_id: this.sessionId ?? undefined,
      events,
      tracking_lib_version: LIB_VERSION,
    }
    if (this.pendingSessionInit) {
      batch.session_init = {
        device_type: detectDevice(),
        browser: detectBrowser(),
        os: detectOs(),
        tracking_lib_version: LIB_VERSION,
      }
    }
    return batch
  }

  private async flush() {
    if (!this.enabled || this.buffer.length === 0 || this.flushing) return

    // Sempre tenta token fresco — lastAuthToken só cobre unload/beacon.
    let token: string | null = null
    try {
      token = await Promise.resolve(this.config.getAuthToken())
    } catch {
      token = null
    }
    if (!token) token = this.lastAuthToken
    if (!token) {
      this.log('warn', 'flush abortado: sem JWT')
      this.scheduleJwtRetry()
      return
    }
    this.lastAuthToken = token
    this.flushing = true

    const events = this.buffer.splice(0, this.config.flushThreshold * 2)
    const batch = this.buildBatch(events)

    try {
      const res = await fetch(this.config.ingestEndpoint, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(batch),
        keepalive: true,
      })

      if (!res.ok) {
        this.log('error', 'flush falhou', res.status, await res.text())
        // 401: JWT inválido/expirado — limpa cache para próximo flush pedir de novo.
        if (res.status === 401) this.lastAuthToken = null
        this.buffer.unshift(...events)
        return
      }

      const data = await res.json() as { ok: boolean, session_id?: string }
      if (data.session_id) {
        this.sessionId = data.session_id
        this.pendingSessionInit = false
      }
      this.log('info', `flush ok — ${events.length} eventos enviados`)
    } catch (err) {
      this.log('error', 'flush network error', err)
      this.buffer.unshift(...events)
    } finally {
      this.flushing = false
    }
  }

  /**
   * Flush síncrono no unload/background. Não pode await getAuthToken —
   * usa só o JWT cacheado + fetch keepalive (sendBeacon não leva Authorization).
   */
  private flushBeacon() {
    if (!this.enabled || this.buffer.length === 0) return
    const token = this.lastAuthToken
    if (!token) {
      const maybe = this.config.getAuthToken()
      if (typeof maybe === 'string' && maybe) {
        this.lastAuthToken = maybe
      } else {
        this.log('warn', 'flushBeacon abortado: sem JWT cacheado')
        return
      }
    }
    const auth = this.lastAuthToken
    if (!auth) return

    const events = this.buffer.splice(0, this.buffer.length)
    const body = JSON.stringify(this.buildBatch(events))
    try {
      void fetch(this.config.ingestEndpoint, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'authorization': `Bearer ${auth}`,
        },
        body,
        keepalive: true,
      }).then(async (res) => {
        if (!res.ok) {
          this.buffer.unshift(...events)
          this.log('error', 'flushBeacon falhou', res.status)
          return
        }
        try {
          const data = await res.json() as { session_id?: string }
          if (data.session_id) {
            this.sessionId = data.session_id
            this.pendingSessionInit = false
          }
        } catch {
          // ignore parse on unload
        }
      }).catch(() => {
        this.buffer.unshift(...events)
      })
    } catch (err) {
      this.buffer.unshift(...events)
      this.log('error', 'flushBeacon network error', err)
    }
  }

  shutdown() {
    if (this.flushTimer) clearInterval(this.flushTimer)
    this.flushTimer = null
    if (this.authWarmTimer) clearInterval(this.authWarmTimer)
    this.authWarmTimer = null
    if (this.jwtRetryTimer) clearTimeout(this.jwtRetryTimer)
    this.jwtRetryTimer = null
    void this.flush()
    this.initialized = false
  }

  private log(level: 'info' | 'warn' | 'error', ...args: unknown[]) {
    if (!this.config.debug && level === 'info') return
    const fn = level === 'error' ? console.error : level === 'warn' ? console.warn : console.log
    fn(...args)
  }
}

export const tracker = new Tracker()
