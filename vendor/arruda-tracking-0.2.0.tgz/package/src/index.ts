// =============================================================================
// @arruda/tracking — entrypoint principal
// =============================================================================

import { tracker } from './tracker'
import type { TrackingConfig } from './types'

export type { TrackingConfig, TrackingEvent, EventType, TrackingMode } from './types'
export { LIB_VERSION } from './types'
export { normalizePagePath } from './normalizePath'

export function initTracking(config: TrackingConfig): void {
  tracker.init(config)
}

export function trackEvent(name: string, properties?: Record<string, unknown>): void {
  tracker.trackEvent(name, properties)
}

export function trackPageView(pagePath?: string, pageTitle?: string): void {
  tracker.trackPageView(pagePath, pageTitle)
}

export function trackClick(name: string, properties?: Record<string, unknown>): void {
  tracker.trackClick(name, properties)
}

export function trackFormSubmit(name: string, properties?: Record<string, unknown>): void {
  tracker.trackFormSubmit(name, properties)
}

export function shutdownTracking(): void {
  tracker.shutdown()
}
