// =============================================================================
// @arruda/tracking/react — hooks React opcionais
// =============================================================================
// Importar com:  import { useTrackPageView } from '@arruda/tracking/react'

import { useEffect, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import { trackPageView } from './index'

/**
 * Dispara track de page_view automaticamente sempre que a rota muda.
 * Também mede o tempo de permanência na página anterior (duration_ms).
 *
 * Uso típico: colocar uma vez no layout raiz da aplicação.
 */
export function useTrackPageView(): void {
  const location = useLocation()
  const enteredAtRef = useRef<number>(Date.now())
  const prevPathRef  = useRef<string | null>(null)

  useEffect(() => {
    const now = Date.now()
    const duration = prevPathRef.current ? now - enteredAtRef.current : undefined

    trackPageView(location.pathname, typeof document !== 'undefined' ? document.title : undefined)

    // Se havia uma página anterior, já registramos acima com occurred_at novo;
    // a duração da PÁGINA ANTERIOR vai nas propriedades do primeiro evento novo.
    // (Uma alternativa é emitir um evento separado "page_exit" — decidir em iteração futura.)
    void duration

    prevPathRef.current = location.pathname
    enteredAtRef.current = now
  }, [location.pathname])
}
