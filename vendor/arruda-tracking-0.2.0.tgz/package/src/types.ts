// =============================================================================
// @arruda/tracking — tipos públicos
// =============================================================================

export type EventType = 'page_view' | 'click' | 'form_submit' | 'api_call' | 'custom'

export interface TrackingEvent {
  event_id: string
  event_type: EventType
  event_name?: string
  page_path?: string
  page_title?: string
  duration_ms?: number
  properties?: Record<string, unknown>
  occurred_at: string
  module_name?: string
}

export interface SessionInit {
  device_type: 'desktop' | 'mobile' | 'tablet'
  browser: string
  os: string
  tracking_lib_version: string
}

export interface IngestBatch {
  project_slug: string
  session_id?: string
  session_init?: SessionInit
  events: TrackingEvent[]
  tracking_lib_version: string
}

export type TrackingMode = 'frequency' | 'full'

export interface TrackingConfig {
  /** Slug do projeto em rbac_projects (ex: 'arruda-sales-boost'). */
  projectSlug: string
  /** URL base do Supabase. Ex: https://kgzy...supabase.co */
  supabaseUrl: string
  /**
   * Função que retorna o JWT do usuário autenticado (access token do Supabase).
   * Normalmente: () => supabase.auth.getSession().then(s => s.data.session?.access_token ?? null)
   */
  getAuthToken: () => Promise<string | null> | string | null
  /** Endpoint da edge function. Default: `${supabaseUrl}/functions/v1/rbac-analytics-ingest` */
  ingestEndpoint?: string
  /**
   * `frequency` (default): só envia page_view — suficiente para o dashboard RBAC.
   * Detalhe de produto (clicks, funis) fica no PostHog; erros no Sentry.
   * `full`: envia também click / form_submit / custom.
   */
  mode?: TrackingMode
  /** Flush a cada N ms. Default 10000 (10s). */
  flushIntervalMs?: number
  /** Flush ao atingir N eventos. Default 20. */
  flushThreshold?: number
  /** Tamanho máximo do buffer antes de começar a descartar os mais antigos. Default 500. */
  maxBufferSize?: number
  /** Idle timeout para encerrar sessão (em ms). Default 1800000 (30min). */
  sessionIdleTimeoutMs?: number
  /** Respeitar DNT do navegador. Default true. */
  respectDoNotTrack?: boolean
  /** Sub-módulo opcional (para apps com múltiplos contextos internos). */
  moduleName?: string
  /** Habilita logs no console para debug. Default false. */
  debug?: boolean
}

export const LIB_VERSION = '0.2.0'
