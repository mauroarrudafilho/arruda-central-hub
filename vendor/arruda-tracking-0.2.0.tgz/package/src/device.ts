// =============================================================================
// Detecção leve de device/browser/OS. Evita depender de libs externas.
// =============================================================================

export function detectDevice(): 'desktop' | 'mobile' | 'tablet' {
  if (typeof navigator === 'undefined') return 'desktop'
  const ua = navigator.userAgent.toLowerCase()
  if (/ipad|tablet|playbook|silk/.test(ua)) return 'tablet'
  if (/mobi|iphone|ipod|android.*mobile|blackberry|iemobile|opera mini/.test(ua)) return 'mobile'
  return 'desktop'
}

export function detectBrowser(): string {
  if (typeof navigator === 'undefined') return 'unknown'
  const ua = navigator.userAgent
  if (/Edg\//.test(ua)) return 'Edge'
  if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) return 'Chrome'
  if (/Firefox\//.test(ua)) return 'Firefox'
  if (/Safari\//.test(ua) && !/Chrome/.test(ua)) return 'Safari'
  if (/OPR\//.test(ua)) return 'Opera'
  return 'other'
}

export function detectOs(): string {
  if (typeof navigator === 'undefined') return 'unknown'
  const ua = navigator.userAgent
  if (/Windows NT/.test(ua)) return 'Windows'
  if (/Mac OS X/.test(ua)) return 'macOS'
  if (/Android/.test(ua)) return 'Android'
  if (/iPhone|iPad|iPod/.test(ua)) return 'iOS'
  if (/Linux/.test(ua)) return 'Linux'
  return 'other'
}

export function isDoNotTrack(): boolean {
  if (typeof navigator === 'undefined') return false
  // @ts-expect-error — navigator.doNotTrack tem tipagens inconsistentes entre browsers
  const dnt = navigator.doNotTrack ?? navigator.msDoNotTrack ?? window.doNotTrack
  return dnt === '1' || dnt === 'yes' || dnt === true
}
