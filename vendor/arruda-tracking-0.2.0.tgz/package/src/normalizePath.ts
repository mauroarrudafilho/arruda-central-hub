// Colapsa IDs e remove query/hash — espelha rbac_analytics_normalize_path no banco.
// Mantém o ranking de frequência legível (rotas, não UUIDs).

const UUID_RE =
  /\/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/gi
const NUMERIC_ID_RE = /\/\d+(?=\/|$)/g
const LONG_HEX_RE = /\/[0-9a-f]{24,}/gi

export function normalizePagePath(path: string | undefined | null): string | undefined {
  if (!path) return path ?? undefined
  let p = path.split('?')[0]?.split('#')[0] ?? path
  p = p.replace(UUID_RE, '/:id')
  p = p.replace(NUMERIC_ID_RE, '/:id')
  p = p.replace(LONG_HEX_RE, '/:id')
  return p || '/'
}
