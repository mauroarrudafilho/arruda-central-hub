# @arruda/tracking

Lib compartilhada de **frequência de uso** para os apps do ArrudaHub. Captura `page_view`, bufferiza e envia em batch para a edge `rbac-analytics-ingest` (arruda-rbac-master).

> **Divisão de responsabilidades (Jul/2026)**  
> - **RBAC / esta lib:** quem usa, com que frequência, quais rotas (paths normalizados).  
> - **PostHog:** funis, feature flags, product analytics, session replay.  
> - **Sentry:** erros, performance, release health.

Fase 6 — Platform Analytics. Ver `ROADMAP.md` e `LESSONS.md` no RBAC Master.

## Instalação

```
echo "@arruda:registry=https://npm.pkg.github.com" >> ~/.npmrc
npm install @arruda/tracking
```

Ou, em monorepo local: `file:../arruda-rbac-master/packages/tracking` após `npm run build` no pacote.

## Uso mínimo (recomendado — mode frequency)

No bootstrap do app (`src/main.tsx` ou equivalente):

```ts
import { initTracking } from '@arruda/tracking'
import { supabase } from '@/lib/supabase'

initTracking({
  projectSlug: 'arruda-hub-commercial-core', // slug em rbac_projects
  supabaseUrl: import.meta.env.VITE_SUPABASE_URL,
  getAuthToken: async () => {
    const { data } = await supabase.auth.getSession()
    return data.session?.access_token ?? null
  },
  mode: 'frequency', // default — só page_view
  debug: import.meta.env.DEV,
})
```

No layout raiz (React Router):

```tsx
import { useTrackPageView } from '@arruda/tracking/react'

export function AppLayout() {
  useTrackPageView()
  return <Outlet />
}
```

Isso basta para popular Dashboard / Analytics do RBAC.

## Modos

| Mode | O que envia ao RBAC | Quando usar |
|---|---|---|
| `frequency` (default) | só `page_view` | Todos os apps — governança de uso |
| `full` | page_view + click + form + custom | Legado / debug; preferir PostHog para isso |

Em `frequency`, chamadas a `trackClick` / `trackFormSubmit` / `trackEvent` são **ignoradas** (não vão pro ingest). Use PostHog no app para esses sinais.

## Paths normalizados

Antes do flush, a lib colapsa UUIDs/IDs e remove `?query` / `#hash`:

- `/clientes/550e8400-…` → `/clientes/:id`
- `/acordos/42/edit` → `/acordos/:id/edit`
- `/minhas-comissoes?tab=1` → `/minhas-comissoes`

O banco aplica a mesma regra (`rbac_analytics_normalize_path`) no ranking.

## Checklist — ligar num app novo

1. [ ] App tem linha em `rbac_projects` com `slug` estável  
2. [ ] `npm install @arruda/tracking` (ou link local)  
3. [ ] `initTracking({ projectSlug, supabaseUrl, getAuthToken })` no bootstrap  
4. [ ] `useTrackPageView()` no layout autenticado  
5. [ ] Usuário autenticado (sem JWT o flush aborta em silêncio)  
6. [ ] Confirmar no RBAC → Analytics → Rotas após navegar 2–3 telas  
7. [ ] PostHog / Sentry já no app para detalhe (não duplicar funis no RBAC)

## O que NÃO passar em `properties`

Mesmo em `mode: 'full'`, o ingest remove PII. Evite no client: email, CPF, tokens, senhas, endereço.

## Observações técnicas

- Buffer: flush a cada 10s ou 20 eventos  
- Dedupe: `event_id` + `occurred_at`  
- Sessão: idle 30min  
- Respeita Do Not Track por default  
- Sem JWT → flush abortado (só usuários logados)

## Desenvolvimento

```
cd packages/tracking
npm install
npm run build
```

Versão atual: **0.2.0** (`mode` + normalize de path no client).
